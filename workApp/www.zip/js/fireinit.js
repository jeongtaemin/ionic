  // Initialize Firebase
  var fb_config = {
    apiKey: "AIzaSyBlo5e5rdUxB83PdLYnk6DaGwXX6Tto8Zw",
    authDomain: "architimes-d707e.firebaseapp.com",
    databaseURL: "https://architimes-d707e.firebaseio.com",
    storageBucket: "architimes-d707e.appspot.com",
    messagingSenderId: "852740390342"
  };
  firebase.initializeApp(fb_config);